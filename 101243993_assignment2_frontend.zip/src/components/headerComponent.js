import React from "react";
import "../App.css";

export default function HeaderComponent() {
  return (
    <div>
      <h1 className="header">Employee Management App</h1>
    </div>
  );
}
